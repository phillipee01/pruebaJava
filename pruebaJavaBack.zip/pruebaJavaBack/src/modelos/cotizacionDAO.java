package modelos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import modelos.cotizacionVO;

public class cotizacionDAO {
	private final String tabla = "cotizaciones";
	   public void guardar(Connection conexion, cotizacionVO cotizacion) throws SQLException{
	      try{
	         PreparedStatement consulta = null;
	         if(cotizacion.getId() == 0){
	            consulta = conexion.prepareStatement("INSERT INTO " + this.tabla + "(idmarca,idmodelo,email, ano) VALUES( ?, ?, ?, ?)");
	            consulta.setInt(1, cotizacion.getIdmarca());
	            consulta.setInt(2, cotizacion.getIdmodelo());
	            consulta.setString(3, cotizacion.getEmail());
	            consulta.setInt(4, cotizacion.getAno());
	         }
	         consulta.executeUpdate();
	      }catch(SQLException ex){
	         throw new SQLException(ex);
	      }
	   }
	   public List<cotizacionVO> recuperarTodas(Connection conexion) throws SQLException{
	      List<cotizacionVO> cotizaciones = new ArrayList<cotizacionVO>();
	      try{
	         PreparedStatement consulta = conexion.prepareStatement("SELECT id, titulo, descripcion, nivel_de_prioridad FROM " + this.tabla + " ORDER BY id");
	         ResultSet resultado = consulta.executeQuery();
	         while(resultado.next()){
	        	 cotizacionVO co=new cotizacionVO();
	        	 co.setIdmarca(resultado.getInt("idmarca"));
	        	 co.setIdmodelo(resultado.getInt("idmodelo"));
	        	 co.setEmail(resultado.getString("email"));
	        	 co.setAno(resultado.getInt("ano"));
	        	 cotizaciones.add(co);
	         }
	      }catch(SQLException ex){
	         throw new SQLException(ex);
	      }
	      return cotizaciones;
	   }
}
