package modelos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class marcasDAO {
	private final String tabla = "marcas";
	   public List<marcasVO> recuperarTodas(Connection conexion) throws SQLException{
		      List<marcasVO> cotizaciones = new ArrayList<marcasVO>();
		      try{
		         PreparedStatement consulta = conexion.prepareStatement("SELECT id, nombre FROM " + this.tabla + " ORDER BY id");
		         ResultSet resultado = consulta.executeQuery();
		         while(resultado.next()){
		        	 marcasVO co=new marcasVO();
		        	 co.setId(resultado.getInt("id"));
		        	 co.setNombre(resultado.getString("nombre"));
		        	 cotizaciones.add(co);
		         }
		      }catch(SQLException ex){
		         throw new SQLException(ex);
		      }
		      return cotizaciones;
		   }
}
