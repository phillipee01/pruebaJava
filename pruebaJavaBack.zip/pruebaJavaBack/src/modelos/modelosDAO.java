package modelos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class modelosDAO {
	private final String tabla = "modelos";
	public List<modelosVO> recuperarTodas(Connection conexion) throws SQLException{
	      List<modelosVO> cotizaciones = new ArrayList<modelosVO>();
	      try{
	         PreparedStatement consulta = conexion.prepareStatement("SELECT id, nombre FROM " + this.tabla + " ORDER BY id");
	         ResultSet resultado = consulta.executeQuery();
	         while(resultado.next()){
	        	 modelosVO co=new modelosVO();
	        	 co.setId(resultado.getInt("id"));
	        	 co.setNombre(resultado.getString("nombre"));
	        	 cotizaciones.add(co);
	         }
	      }catch(SQLException ex){
	         throw new SQLException(ex);
	      }
	      return cotizaciones;
	   }
}
