package webservice;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import modelos.cotizacionDAO;
import modelos.cotizacionVO;

/**
 * Servlet implementation class webservice
 */
@WebServlet("/webservice")
public class webservice extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public webservice() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		cotizacionDAO co=new cotizacionDAO();
		String servidor="127.0.0.1";
	    String database="pruebaJava";
	    String usuario="root";
	    String password="";
		conexion conec=new conexion(servidor, database, usuario, password);
		try {
			co.recuperarTodas(conec.getConexion());
			conec.cerrarConexion();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		cotizacionDAO co=new cotizacionDAO();
		String servidor="127.0.0.1";
	    String database="pruebaJava";
	    String usuario="root";
	    String password="";
		conexion conec=new conexion(servidor, database, usuario, password);
		cotizacionVO coVO=new cotizacionVO();
		coVO.setIdmodelo(Integer.parseInt(request.getParameter("modelo")));
		coVO.setIdmarca(Integer.parseInt(request.getParameter("marca")));
		coVO.setEmail(request.getParameter("modelo"));
		coVO.setAno(Integer.parseInt(request.getParameter("ano")));
		try {
			co.guardar(conec.getConexion(), coVO);
			conec.cerrarConexion();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		doGet(request, response);
	}

}
